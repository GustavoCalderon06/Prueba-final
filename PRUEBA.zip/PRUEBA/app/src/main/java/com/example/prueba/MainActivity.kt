package com.example.prueba



import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var socket: Socket
    private lateinit var calderaEstadoTextView: TextView
    private lateinit var ultimaHoraTextView: TextView
    private var ultimoTimestampRecibido: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        calderaEstadoTextView = findViewById(R.id.calderaEstadoTextView)
        ultimaHoraTextView = findViewById(R.id.ultimaHoraTextView)

        try {
            socket = IO.socket("http://52.200.139.211:5000") // Reemplaza con tu dirección IP y puerto
            socket.connect()

            socket.on("update_data") { args ->
                val data = args[0] as JSONObject
                val activo = data.getBoolean("activo")
                val timestamp = data.optString("timestamp", "")

                runOnUiThread {
                    actualizarEstadoCaldera(activo)
                    actualizarUltimaHora(timestamp)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun actualizarEstadoCaldera(activo: Boolean) {
        if (activo) {
            calderaEstadoTextView.text = "Estado de la Caldera: Activa"
            calderaEstadoTextView.setTextColor(Color.GREEN)
        } else {
            calderaEstadoTextView.text = "Estado de la Caldera: Detenida"
            calderaEstadoTextView.setTextColor(Color.RED)
        }
    }

    private fun actualizarUltimaHora(timestamp: String?) {
        timestamp?.let { // Verifica si timestamp no es null
            if (it.isNotEmpty()) {
                // Si recibimos un timestamp válido, lo actualizamos y lo mostramos
                ultimoTimestampRecibido = it
                ultimaHoraTextView.text = "Última Hora de Funcionamiento: $ultimoTimestampRecibido"
            } else {
                Log.d("MainActivity", "Timestamp vacío recibido")
                // Si el timestamp está vacío, conservamos el último timestamp válido mostrado
                ultimoTimestampRecibido?.let {
                    ultimaHoraTextView.text = "Última Hora de Funcionamiento: $it"
                }
            }
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        socket.disconnect()
    }
}
